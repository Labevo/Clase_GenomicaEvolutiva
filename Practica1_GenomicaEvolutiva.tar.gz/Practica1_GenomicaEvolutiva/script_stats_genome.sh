#!/bin/bash

Script=$0
Archivo=$1
Gene=$2

echo "Datos del Genoma"


perl -pe '/^[^>]/ and $_=~ s/[a-z]/n/g' $1 > temp

Longitud_genoma= awk '/^>/ {if (seqlen) print seqlen;print;seqlen=0;next} {seqlen+=length($0)}END{print seqlen}' temp | grep -v ">" | awk '{sum+=$1;}END{print sum;}' | sed 's/^/Tamaño genoma:\t/g'
Longitud_gene= awk '/^>/ {if (seqlen) print seqlen;print;seqlen=0;next} {seqlen+=length($0)}END{print seqlen}' $2 | grep -v ">" | awk '{sum+=$1;}END{print sum;}' | sed 's/^/Region Codificante:\t/g'
Freqn= awk -v RS=\n 'END{print NR-1}' temp | sed 's/^/Elementos Transponibles:\t/g'

echo "Frecuencia de nucleotidos en el genoma"

FreqA= awk -v RS=\A 'END{print NR-1}' temp | sed 's/^/A:\t/g'
FreqT= awk -v RS=\T 'END{print NR-1}' temp | sed 's/^/T:\t/g'
FreqG= awk -v RS=\G 'END{print NR-1}' temp | sed 's/^/G:\t/g'
FreqC= awk -v RS=\C 'END{print NR-1}' temp | sed 's/^/C:\t/g'
FreqN= awk -v RS=\N 'END{print NR-1}' temp | sed 's/^/N:\t/g'

rm temp
