#!/bin/bash
Script=$0
Genoma=$1

NumScaff=$(grep -c ">" $1)

TamGenome=$(awk '/^>/ {if (seqlen) print seqlen;print;seqlen=0;next} {seqlen+=length($0)}END{print seqlen}' $1 | grep -v ">" | awk '{sum+=$1;}END{print sum;}')

MinScaf=$(awk '/^>/ {if (seqlen) print seqlen;print;seqlen=0;next} {seqlen+=length($0)}END{print seqlen}' $1 | awk '{print$NF}' | sort -nr | head -n1)

MaxScaf=$(awk '/^>/ {if (seqlen) print seqlen;print;seqlen=0;next} {seqlen+=length($0)}END{print seqlen}' $1 | grep -v ">" | awk '{print$NF}' | sort -n | head -n 1)
Midlen=$(awk '/^>/ {if (seqlen) print seqlen;print;seqlen=0;next} {seqlen+=length($0)}END{print seqlen}' $1 | grep -v ">" | awk '{sum+=$1; div = sum/2}END{print div;}')

echo "Tamano de genoma: ${TamGenome} pb"
echo "Numero Scaffolds: ${NumScaff}"
echo "Longitud de Scaffold mas largo: ${MinScaf} pb"
echo "Longitud de Scaffold pequeno: ${MaxScaf} pb"
echo "La mitad del genoma tiene una longitud: ${Midlen} pb"
echo "(Dividir el tamano de genoma= ${TamGenome} / 2)"

awk '/^>/ {if (seqlen) print seqlen;print;seqlen=0;next} {seqlen+=length($0)}END{print seqlen}' $1 | grep -v ">" > Temp1
awk '/^>/ {if (seqlen) print seqlen;print;seqlen=0;next} {seqlen+=length($0)}END{print seqlen}' $1 | grep ">" | sed -e '/^>/ s/\(>\S\+\)\s.*$/\1/' > Temp2
paste -d"\t" Temp2 Temp1 | sort -nrk 2 > Tabla_tamanoScaffolds.txt
rm Temp*

exit 0
